package com.icia.boardjsp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardJspApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardJspApplication.class, args);
	}

}
