package com.icia.boardjsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardJspApplicationTests {

	@Test
	void contextLoads() {
	}

}
