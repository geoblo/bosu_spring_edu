package com.icia.start01.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataDto {
    private String name;
    private int age;
    private String address;
}
