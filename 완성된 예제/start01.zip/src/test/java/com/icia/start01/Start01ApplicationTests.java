package com.icia.start01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Start01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
